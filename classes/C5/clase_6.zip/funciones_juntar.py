def join_list(lista):
    return ", ".join(lista)