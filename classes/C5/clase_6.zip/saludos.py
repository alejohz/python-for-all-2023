def saludar_nombre(nombre):
    return f"Hola {nombre}"
