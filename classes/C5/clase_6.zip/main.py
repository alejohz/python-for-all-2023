from saludos import saludar_nombre

# def saludar_nombre

print(saludar_nombre("Alejandro"))
print(saludar_nombre("Daniel"))
print(saludar_nombre("Maria"))

# from math import sqrt