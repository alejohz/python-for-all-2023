def mini_suma(a):
    return a + a