def despedir():
    print("chao")