def saludar():
    print("Hola")


def saludar_nombre(nombre):
    print("Hola", nombre)
