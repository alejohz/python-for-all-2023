def resta(a, b):
    return a - b